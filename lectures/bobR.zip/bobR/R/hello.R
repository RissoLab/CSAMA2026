#' do PCR on an SCE
#'
#' @param sce an SCE object with cluster annotations
#' @param kid whats the cluster variable (string)
#'
#' @returns a data.frame
#'
#' @examples
#' library(scRNAseq)
#' library(scater)
#' library(scran)
#'
#' sce <- ReprocessedAllenData()
#' sce <- logNormCounts(sce, assay.type="tophat_counts")
#' tbl <- modelGeneVar(sce)
#' hvg <- getTopHVGs(tbl, n=2e3)
#' sce <- runPCA(sce, subset_row=hvg)
#'
#' df <- doPCR(sce, "Primary.Type")
#'
#' @importFrom SingleCellExperiment reducedDim reducedDimNames
#' @importFrom stats lm
#' @export
doPCR <- \(sce, kid) {

    # check inputs
    if (!is(sce, "SingleCellExperiment"))
        stop("input should be an SCE, try again!")
    if (!"PCA" %in% reducedDimNames(sce))
        stop("can't find PCs")

    pcs <- reducedDim(sce, "PCA")
    fit <- summary(lm(pcs ~ sce[[kid]] - 1))
    r2 <- sapply(fit, \(.) .$adj.r.squared)
    data.frame(pc=seq_along(r2), r2)
}

#' plot PCR results
#'
#' @param df output of doPCR
#'
#' @returns a ggplot
#'
#' @examples
#' # TODO
#'
#' @importFrom ggplot2 aes ggplot geom_line labs
#' @export
.plt <- \(df) {
    ggplot(df, aes(pc, r2)) + geom_line() +
        labs(x="principal component", y="R-squared")
}
