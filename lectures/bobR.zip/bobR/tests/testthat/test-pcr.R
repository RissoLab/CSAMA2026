testthat::test_that("need PCA", {
    se <- SingleCellExperiment::SingleCellExperiment()
    testthat::expect_error(doPCR(se))

    expect_error(doPCR(sce, c(1, 2)))
    expect_error(doPCR(sce, "xxxxxxx"))
})
